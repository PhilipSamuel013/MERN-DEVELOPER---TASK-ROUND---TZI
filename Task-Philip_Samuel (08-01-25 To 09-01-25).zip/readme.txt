******************
Product Management

Step 1: Create React App
        npx create-react-app product-management
        cd product-management

Step 2: Install npm packages 
        1) npm install
        2) npm install @mui/material @emotion/react @emotion/styled react-router-dom react-hook-form web-vitals
        3) npm install @reduxjs/toolkit react-redux

Step 3: Run the project
        npm start
*********************
